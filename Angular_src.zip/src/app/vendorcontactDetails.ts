export class VendorContactDetails
{
    
	vId:number;
	vName:String;
	vAddress:String;
	vLocation:String;
	vService:String; 
	pincode:number; 
	isActive:number;
	cId :number;
	cName :String;
	department:String;
	email:String;
	phone :String;
	searchString:String;
}